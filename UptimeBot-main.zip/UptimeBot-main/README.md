# ```UptimeBot```
___
• V14 slash komutlu form sistemli gelişmiş bir altyapıdır.
___ 
• Botu kendinizin gibi göstermek yasaktır. 
___
• Bir sorunuz olursa [Buradan](https://discord.com/users/873182701061021696) benimle iletişime geçebilirsiniz.
___
• Star atarsanız çok sevinirim şimdiden teşekkürler.
